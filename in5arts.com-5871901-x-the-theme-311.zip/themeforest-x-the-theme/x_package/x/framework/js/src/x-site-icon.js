// =============================================================================
// JS/X-SITE-ICON.JS
// -----------------------------------------------------------------------------
// Icon specific functionality needed in <head> element.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Imports
// =============================================================================

// Imports
// =============================================================================

// @codekit-append "site/x-scripts-icon.js"
// @codekit-append "site/vendor/matchmedia.js"
// @codekit-append "site/vendor/enquire.js"
// @codekit-append "site/vendor/nanoscroller.js"
// @codekit-append "site/x-call-icon.js"

// =include "site/x-scripts-icon.js"
// =include "site/vendor/matchmedia.js"
// =include "site/vendor/enquire.js"
// =include "site/vendor/nanoscroller.js"
// =include "site/x-call-icon.js"